package com.testing.code;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.concurrent.TimeUnit;

import javax.imageio.ImageIO;

import org.apache.commons.collections4.FactoryUtils;
import org.apache.poi.openxml4j.exceptions.InvalidFormatException;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.Keys;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.Point;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.google.common.io.Files;
import com.testing.pages.loginpage;
import com.testing.pages.trelloDashboard;
import ru.yandex.qatools.ashot.AShot;
import ru.yandex.qatools.ashot.Screenshot;

public class trello {

public WebDriver driver;
private loginpage l_page;	
private trelloDashboard t_dpage;
	@Test
	  public void trello() throws IOException, InvalidFormatException, InterruptedException {
		driver.get("https://trello.com/login");
		driver.manage().window().maximize();
		l_page = PageFactory.initElements(driver, loginpage.class);
		t_dpage =  PageFactory.initElements(driver, trelloDashboard.class);
		//reading input from excel
		FileInputStream inputsheet = new FileInputStream("./src/main/resources/sampleinput.xlsx");
		XSSFWorkbook workbook = new XSSFWorkbook(inputsheet);
		XSSFSheet sheet =workbook.getSheetAt(0);
		String Input1 = sheet.getRow(1).getCell(0).getStringCellValue();
		String Input2 = sheet.getRow(1).getCell(1).getStringCellValue();
		
		//logging in
		WebDriverWait wt = new WebDriverWait(driver, 20);
		wt.until(ExpectedConditions.visibilityOf(l_page.email));
		l_page.email.sendKeys(Input1);		
		l_page.login.click();
		Thread.sleep(3000);
		l_page.pwd.sendKeys(Input2);
		l_page.login_submit.click();
		Thread.sleep(10000);
			
		//creating new board and entering title for it

		t_dpage.newBoard.click();
		Thread.sleep(2000);
		t_dpage.boardTitle.sendKeys("Board_05062022");
		Thread.sleep(2000);
		t_dpage.boardCreate.click();
		
		
		//create two new list A and B

		Thread.sleep(3000);
		t_dpage.listTitle.sendKeys("A");
		Thread.sleep(1000);
		t_dpage.listSubmit.click();
		Thread.sleep(2000);
		t_dpage.listTitle.click();
		t_dpage.listTitle.sendKeys("B");
		Thread.sleep(1000);
		t_dpage.listSubmit.click();
	
		//Adding a card to list A
		Thread.sleep(2000);
		t_dpage.addCardA.click();
		Thread.sleep(1000);
		t_dpage.cardTitle.sendKeys("Card from List A");
		Thread.sleep(1000);
		t_dpage.addCard.click();
		Thread.sleep(1000);
		t_dpage.closeCard.click();
		Thread.sleep(1000);
		
		//Move card from A to B
		t_dpage.editCard.click();
		Thread.sleep(1000);
		t_dpage.moveCard.click();
		Thread.sleep(1000);
		Select dropdown= new Select(t_dpage.listClick);
		Thread.sleep(1000);
		dropdown.selectByVisibleText("B");
		Thread.sleep(1000);
		t_dpage.moveButton.click();
		Thread.sleep(1000);
		
		//Get the co-ordinates of moved card in B
	
		Point pt = t_dpage.movedCardInB.getLocation();
		int xcord = pt.getX();
		System.out.println("X coordinate of the card from A to B is "+xcord +" pixels");
		int ycord = pt.getY();
		System.out.println("Y coordinate of the card from A to B is "+ycord +" pixels");
		
		//Log out
		t_dpage.profileIcon.click();
		Thread.sleep(1000);
		t_dpage.logOut.click();
		wt.until(ExpectedConditions.visibilityOf(t_dpage.logOutAtlassian));
		t_dpage.logOut.click();
		}	
	
	  @BeforeClass
	  public void beforeClass() throws InterruptedException {
		  System.out.println("In beforeclass");
		  try {
			  l_page = PageFactory.initElements(driver, loginpage.class);
		  }
		  catch(Exception e) {
			  System.out.println("Exception in beforeclass: "+e);
		  }
		  System.setProperty("webdriver.chrome.driver", "./src/main/resources/chromedriver.exe");
		  driver = new ChromeDriver();
		  
	  }
	 
	  @AfterClass
	  public void afterClass() throws IOException {
			System.out.println("In afterclass");
			driver.close();
	  }
	
	
}
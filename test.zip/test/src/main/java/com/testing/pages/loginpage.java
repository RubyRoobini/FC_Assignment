package com.testing.pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class loginpage {
	WebDriver d;
	
	
	
	@FindBy(xpath = "//input[@id='user']")
	public WebElement email;
	
	@FindBy(xpath = "//input[@id='password']")
	public WebElement pwd;
	
	@FindBy(xpath = "//input[@id='login']")
	public WebElement login;
	
	@FindBy(xpath = "//button[@id='login-submit']")
	public WebElement login_submit;
	
	
	public loginpage(WebDriver d) {
	   this.d = d;
	   }
}

package com.testing.pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class trelloDashboard {

		WebDriver d;
		@FindBy(xpath = "//div[@class='board-tile mod-add']")
		public WebElement newBoard;
		
		@FindBy(xpath = "//input[@class='nch-textfield__input _2N2CjUFKhgeXLO _2N2CjUFKhgeXLO _3pXGTS3_pwahBt']")
		public WebElement boardTitle;
		
		@FindBy(xpath = "//button[text()='Create']")
		public WebElement boardCreate;
	
		@FindBy(xpath = "//a[@class='open-add-list js-open-add-list']")
		public WebElement addNewList;
		@FindBy(xpath = "//input[@class='list-name-input']")
		public WebElement listTitle;
		@FindBy(xpath = "//input[@type='submit']")
		public WebElement listSubmit;
		@FindBy(xpath = "(//a[@class='board-tile'])[1]")
		public WebElement board_;
		@FindBy(xpath = "//div[@class='js-list list-wrapper']//h2[text()='A']/parent::div/following-sibling::div[@class='card-composer-container js-card-composer-container']/a")
		public WebElement addCardA;
		@FindBy(xpath = "//textarea[@class='list-card-composer-textarea js-card-title']")
		public WebElement cardTitle;
		
		@FindBy(xpath = "//input[@value='Add card']")
		public WebElement addCard;
		

		@FindBy(xpath = "//a[@class='icon-lg icon-close dark-hover js-cancel']")
		public WebElement closeCard;
		
		@FindBy(xpath = "//span[text()='Card from List A']/parent::div/preceding-sibling::span")
		public WebElement editCard;
		@FindBy(xpath = "//span[text()='Move']/parent::a")
		public WebElement moveCard;
		
		
		@FindBy(xpath = "//select[@class='js-select-list']")
		public WebElement listClick;
		@FindBy(xpath = "//input[@value='Move']")
		public WebElement moveButton;
		
		@FindBy(xpath = "//div[@class='js-list list-wrapper']//h2[text()='B']/parent::div/following-sibling::div[1]/a")
		public WebElement movedCardInB;
		@FindBy(xpath = "//div[@class='_2LKdO6O3n25FhC']")
		public WebElement profileIcon;
		@FindBy(xpath = "//span[text()='Log out']")
		public WebElement logOut;
		@FindBy(xpath = "//img[@alt='Trello Logo']")
		public WebElement logOutAtlassian;
		
		public trelloDashboard(WebDriver d) {
			   this.d = d;
			   }
	
}
